#pragma once
#include <functional>
#include <asp/fs.hpp>

namespace FileIO {
    void exportFWC();
    void importReplay(std::function<void()> onSuccessCallback);

    void exportToFile(const asp::fs::Path& path, bool isJson);
    void importFromFile(const asp::fs::Path& path, std::function<void()> onSuccessCallback);
}