#pragma once
#include "../Data/Types.hpp"
#include <vector>
#include <cstdint>
#include <asp/fs.hpp>

namespace CmlParser {
    struct CmlParseResult {
        std::vector<FrameAction> actions;
        double fps = 240.0;
        bool hasFps = false;
    };

    CmlParseResult parse(const asp::fs::Path& path);
    CmlParseResult parse(const std::vector<uint8_t>& data);
}
